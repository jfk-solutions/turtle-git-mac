struct StatusSummary {
    var modified = 0
    var staged = 0
    var untracked = 0
}
