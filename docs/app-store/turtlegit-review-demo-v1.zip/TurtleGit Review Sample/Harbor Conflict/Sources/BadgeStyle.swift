enum BadgeStyle {
<<<<<<< HEAD
    case green, red, orange, gray, blue
=======
    case cleanGreen, changedAmber, conflictRed, ignoredGray
>>>>>>> feature/review-colors
}
