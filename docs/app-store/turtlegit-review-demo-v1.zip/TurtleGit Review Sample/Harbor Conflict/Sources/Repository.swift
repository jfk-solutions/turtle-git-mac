import Foundation

struct Repository {
    let path: URL
}
