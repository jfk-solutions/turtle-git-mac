# Review changes

Compare the staged and working versions before committing.
