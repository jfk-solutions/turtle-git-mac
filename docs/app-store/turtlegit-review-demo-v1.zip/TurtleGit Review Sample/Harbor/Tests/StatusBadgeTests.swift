import XCTest

final class StatusBadgeTests: XCTestCase {
    func testStatusName() { XCTAssertEqual("clean", "clean") }
}
