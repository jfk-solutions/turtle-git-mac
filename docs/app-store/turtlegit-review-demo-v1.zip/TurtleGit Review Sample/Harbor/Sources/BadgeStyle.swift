enum BadgeStyle {
    case green, red, orange, gray
}
