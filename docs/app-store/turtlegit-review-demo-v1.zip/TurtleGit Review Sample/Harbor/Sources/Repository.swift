import Foundation

struct Repository {
    let path: URL
    var name: String { path.lastPathComponent }
}

// Working-tree draft: keep the staged change separate.
