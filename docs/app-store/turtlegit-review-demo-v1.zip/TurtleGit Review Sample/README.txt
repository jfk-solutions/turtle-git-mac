TurtleGit for Mac — offline review sample, version 1

All names, email addresses and project contents in this archive are synthetic.
The sample contains no credentials, external server, executable Git hooks,
submodules, alternates, symbolic links or personal repository history.
It is supplied under the accompanying GNU GPL version 2 license.

GET STARTED
1. Extract this archive into a new folder you own. Keep this README, the two
   repositories and History.bundle together. Do not use a personal repository.
2. In TurtleGit choose Open Repository and select Harbor. The normal folder
   chooser grants access. From Finder, Add to TurtleGit registers that selected
   repository for menus/badges without opening a workspace. Enable the extension
   in System Settings if necessary. Registration does not enable refresh after
   Quit automatically.
3. Open Log: inspect main, feature/status-badges, feature/offline-help,
   release/1.0, the merge commits and the annotated preview/release tags. Select
   commits to inspect messages, changed paths, comparisons and Blame.
4. Open Check for modifications or Commit. Sources/Repository.swift has BOTH
   staged and unstaged changes. README.md is modified, Docs/QuickStart.md was
   renamed to Docs/GettingStarted.md, Tests/StatusBadgeTests.swift is added, and
   Notes/review-notes.md is untracked. preview.log is ignored. Row highlighting
   and checked membership are independent. With staging enabled, inspect both
   versions before choosing which changes to commit. No signing key is needed;
   a synthetic author is configured only inside these disposable repositories.
5. Open review.patch as a document to inspect the standalone editable Unified
   Diff viewer. Use Save As to a new destination to preserve the supplied patch.
   The matching commit is already in Harbor, so do not apply the patch there.
6. For offline Clone, paste the full path of History.bundle into Clone's URL /
   source field, and choose a NEW empty destination outside this archive. The
   source Browse chooser selects folders; it does not select bundle files. If
   access is requested, authorize the containing sample folder. The clone has
   clean committed history,
   without Harbor's demonstration edits. Successful Clone should register its
   destination automatically. The bundle is a read-only sample source; do not
   attempt Push or require any online account to review this attachment.
7. Open Harbor Conflict. It intentionally has an unfinished merge, with one
   conflict in Sources/BadgeStyle.swift. Compare/resolve it, choose the desired
   content, save and mark it resolved. Commit to finish the sample merge, or
   choose Abort Merge to return to its main branch. Do not assume the original
   conflict remains after resolving/aborting; extract a fresh copy to repeat.

EXPECTED INITIAL STATE
expected.json records the exact commit IDs, branches, tags and porcelain status
for both repositories, and the patch/bundle checksums. It describes the supplied
initial state, not a state TurtleGit must force after your review mutations.

RESET AND CLEANUP
Extract a new copy to a different folder to start again. The generator never
resets or overwrites an existing checkout. After review, remove only these sample
repositories from TurtleGit's saved access/watched roots and discard the sample
folder or your explicit clone. Restore any background-refresh preference you
changed. Do not clear unrelated histories, grants, Keychain items or Finder
windows. The app and Finder extension need no blanket disk permission.

This is local review data, not evidence of complete upstream parity, network
authentication, Office automation, email delivery or App Store approval.
